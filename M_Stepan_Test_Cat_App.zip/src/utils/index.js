export const darkThemeColor="#119d91";
export const lightThemeColor="#aaf5ef";